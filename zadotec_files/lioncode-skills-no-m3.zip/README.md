# Skills do LionCode

Os cinco comandos do LionCode extraídos como skills do Claude Code, invocáveis
diretamente em qualquer projeto — sem depender do LionCode.

Cada arquivo é uma skill autocontida. Para usar, coloque cada uma em
`~/.claude/skills/<nome>/SKILL.md` e reinicie a sessão do Claude Code:

```
~/.claude/skills/
  spec/SKILL.md
  featdevelop/SKILL.md
  featsprints/SKILL.md
  featbuild/SKILL.md
  bugreview/SKILL.md
```

Depois é só digitar `/spec`, `/featbuild` etc. no composer, ou pedir em
linguagem natural — as descrições no frontmatter cobrem os dois caminhos.

## Os comandos

| Arquivo | Comando | O que faz |
|---|---|---|
| `spec.md` | `/spec` | Ideia solta → especificação estruturada, seção a seção, fechada por dois validadores independentes com gate de zero apontamentos bloqueantes |
| `featdevelop.md` | `/featdevelop` | Pipeline completo de planejamento: PRD → TECH → SPEC → sprints, com validadores adversariais por fase e aprovação sua entre elas |
| `featsprints.md` | `/featsprints` | SPEC pronta → sprints executáveis em ondas, com tabela de cobertura |
| `featbuild.md` | `/featbuild` | Executa as sprints em ondas paralelas, cada uma em worktree isolado, com Dev e Validador iterando até zerar os findings |
| `bugreview.md` | `/bugreview` | Dois tracers paralelos (código e comportamento) → ficha revisável BUG/TRACE/DIAGNÓSTICO |

## O fluxo típico

```
ideia ──> /featdevelop ──────────────────> /featbuild ──> revisão de diffs
      └─> /spec ──> /featsprints ────────┘

bug ──> /bugreview ──> (ficha aprovada) ──> /featsprints ──> /featbuild
```

## Como isso difere do LionCode

O LionCode roda o build como job supervisionado fora da conversa, com retry
automático e pausa/retomada geridos pelo motor. Aqui esse motor não existe, então
o `/featbuild` roda dentro da sessão com subagentes paralelos, e a retomada segura
foi reproduzida com um arquivo de estado (`BUILD-STATE.md`) em vez de supervisor
de processo.

Os gates humanos foram preservados: `/featdevelop` e `/bugreview` param e esperam
sua aprovação, e o `/featbuild` deixa tudo não commitado para sua revisão de diffs.
