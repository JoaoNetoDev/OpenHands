---
name: spec
description: Transforma uma ideia solta em uma especificação de design estruturada, iterando seção a seção com o usuário e fechando com dois validadores independentes que só liberam a spec com zero apontamentos bloqueantes. Use quando o usuário invocar /spec, pedir "escrever uma spec", "especificar essa feature", "documentar o design antes de codar", ou quando a feature ainda está solta na cabeça dele e precisa virar documento antes de qualquer planejamento ou código.
---

# /spec — Escrever uma especificação

Objetivo: pegar uma ideia ainda vaga e produzir um documento de design estruturado, ancorado no código real do repositório, revisado por validadores independentes.

Esta skill **gruda na conversa**: enquanto ela estiver ativa, toda a conversa (mensagens anteriores e posteriores) é contexto da spec. Não trate mensagens do usuário como pedidos isolados — trate como refinamento da spec em construção.

## Entrada

O usuário dá uma ou poucas frases. Se ele não deu nada além de `/spec`, pergunte **uma** pergunta: qual é a ideia.

## Fase 0 — Ancoragem no repositório

Antes de escrever qualquer coisa:

1. Descubra o stack, a estrutura de pastas e as convenções (leia `CLAUDE.md`/`AGENTS.md` se existirem, `package.json`/manifesto equivalente, e a árvore de diretórios relevante).
2. Localize os módulos que a ideia toca. Anote caminhos reais `arquivo:linha` — eles serão citados na spec.
3. Se a ideia colide com algo que já existe, diga isso ao usuário antes de seguir.

Nunca invente nome de arquivo, função, tabela, rota ou flag. Tudo que aparecer na spec como referência ao código existente precisa ter sido lido.

## Fase 1 — Elicitação (iterativa, seção a seção)

Percorra as seções abaixo **uma de cada vez**. Para cada seção: escreva sua proposta, mostre ao usuário, incorpore o retorno, só então avance. Não despeje o documento inteiro de uma vez.

Faça no máximo 2–3 perguntas por rodada, e só perguntas onde respostas diferentes mudam materialmente o desenho. Para o resto, decida com base no código e declare a suposição.

Seções:

1. **Problema** — o que dói hoje, para quem, com que frequência. Sem solução aqui.
2. **Objetivo e não-objetivos** — o que essa entrega resolve e o que explicitamente fica de fora.
3. **Estado atual** — como o sistema faz isso hoje, com referências `arquivo:linha`.
4. **Desenho proposto** — a solução: modelo de dados, contratos/interfaces, fluxo principal, pontos de integração. Inclua um diagrama textual ou Mermaid quando o fluxo tiver mais de três saltos.
5. **Alternativas consideradas** — pelo menos uma, com o motivo real da rejeição.
6. **Impacto** — arquivos e módulos afetados, migrações, compatibilidade, feature flag, rollout/rollback.
7. **Casos de borda e falhas** — o que acontece quando dá errado, concorrência, dados legados, limites.
8. **Critérios de aceitação** — lista verificável, cada item testável em uma frase.
9. **Riscos e questões em aberto** — o que ainda não está resolvido, e quem decide.

## Fase 2 — Escrita do documento

Escreva em `docs/specs/<slug>/SPEC.md` (crie os diretórios). `<slug>` é kebab-case derivado do título. Se o repositório já tem uma convenção diferente para docs, siga a do repositório.

O documento é autocontido: alguém que não participou da conversa consegue implementar a partir dele.

## Fase 3 — Validação (dois validadores independentes)

Dispare **dois subagentes em paralelo**, em uma única mensagem, cada um com contexto limpo e o caminho do arquivo da spec. Eles não conversam entre si.

**Validador A — Fidelidade ao código.** Instrução: "Leia `<caminho>`. Para cada referência a arquivo, função, tipo, rota, tabela, comando ou flag, abra o código real e confirme que existe e faz o que a spec diz. Reporte cada divergência como um finding com id estável, severidade (BLOQUEANTE | IMPORTANTE | NOTA), citação da spec e a evidência `arquivo:linha`. Não sugira melhorias de estilo. Se não achar divergência, retorne lista vazia."

**Validador B — Completude e coerência.** Instrução: "Leia `<caminho>`. Verifique: objetivos e não-objetivos coerentes com o desenho; casos de borda cobertos; critérios de aceitação verificáveis e suficientes para cobrir o desenho; ambiguidades que levariam dois desenvolvedores a implementações diferentes; contradições internas. Reporte findings com id estável, severidade (BLOQUEANTE | IMPORTANTE | NOTA) e o trecho exato. Não reescreva a spec."

## Fase 4 — Fechamento

1. Consolide os findings dos dois validadores, deduplicando por assunto e mantendo os ids.
2. Corrija **todos** os BLOQUEANTES na spec. Corrija os IMPORTANTES salvo se houver motivo — e nesse caso registre o motivo na seção de questões em aberto.
3. Rode a validação de novo, com os mesmos dois validadores, sobre a versão corrigida.
4. Repita até **zero findings BLOQUEANTES**. Esse é o gate: não declare a spec pronta antes disso.
5. Apresente ao usuário: caminho do arquivo, resumo em até 5 linhas, e a tabela de findings resolvidos/aceitos.

## Saída

- `docs/specs/<slug>/SPEC.md` pronto.
- Sugira o próximo passo: `/featsprints` apontando para esse arquivo.

