---
name: featbuild
description: Executa sprints planejadas em ondas paralelas, cada uma num worktree git isolado, com um Dev que implementa e itera nos testes e um Validador independente que audita o código real, findings com id estável até zerar, e integração determinística na ordem do plano. Use quando o usuário invocar /featbuild, pedir "constrói as sprints", "executa o plano", "roda o build das sprints", ou logo depois de /featdevelop ou /featsprints quando o plano já está aprovado.
---

# /featbuild — Construir as sprints

Executa o que foi planejado. Uma sprint que cai **não derruba as irmãs**. Nada entra no código do usuário sem ele ver o diff.

## Entrada

O diretório de sprints. Se não foi apontado, procure `docs/features/*/sprints/`. Havendo mais de um, pergunte qual.

## Fase 0 — Pré-voo

1. Leia `PLANO.md` (se existir) e todas as `SPRINT-NN.md`. Monte o grafo de dependências e as ondas.
2. Confirme que o repositório está limpo (`git status`). Se houver mudanças não commitadas, **pare e pergunte** — worktrees partem do HEAD e trabalho não commitado ficaria de fora.
3. Rode o typecheck/lint/test da base **antes de tocar em nada** e registre o baseline. Falha pré-existente vira contexto, não é atribuída a nenhuma sprint.
4. Confirme com o usuário: número de sprints, ondas, e o baseline.

## Fase 1 — Worktrees

Para cada sprint da onda atual, crie um worktree isolado a partir do HEAD:

```bash
git worktree add <dir-worktree> -b sprint/<slug>-NN HEAD
```

Use um diretório fora da árvore do projeto (o scratchpad da sessão serve). Instale as dependências no worktree com o gerenciador do projeto antes de entregar ao Dev — o worktree não herda `node_modules`/venv.

Se worktrees não estiverem disponíveis (repositório não-git, por exemplo), execute as sprints **sequencialmente** na árvore principal e diga isso ao usuário.

## Fase 2 — Execução por onda

Para cada onda, dispare **todas as sprints da onda em paralelo, numa única mensagem** (um subagente Dev por sprint). Ondas rodam em sequência: a onda N+1 só começa depois que a N integrou.

### Loop de cada sprint

**Dev** (subagente, recebe: caminho do worktree, o arquivo da sprint, a SPEC e as convenções do projeto):

> Implemente a SPRINT-NN dentro de `<worktree>`. Trabalhe **só** nos arquivos previstos na sprint; se precisar tocar outro, registre o motivo no relatório. Escreva os testes obrigatórios. Rode os comandos de verificação da sprint e itere até passarem — não relate sucesso sem a saída do comando. Retorne: arquivos alterados, resumo do que fez, saída final dos comandos de verificação, e qualquer desvio do plano.

**Validador** (subagente independente, **contexto limpo**, recebe: o arquivo da sprint, a SPEC e o diff do worktree — nunca o relatório do Dev):

> Audite o código real do worktree contra a SPRINT-NN e a SPEC. Reporte findings com id estável `F-NN-<n>`, severidade (BLOQUEANTE | IMPORTANTE | NOTA), arquivo:linha e o defeito concreto. BLOQUEANTE: critério de aceitação não atendido, teste que não exercita o que diz exercitar, bug de correção, regressão em comportamento existente, requisito da sprint não implementado. Não reescreva o código. Não elogie. Se nada, retorne lista vazia.

**Retorno**: os findings voltam para **o mesmo Dev**, com os ids preservados. O Dev corrige e reporta por id. O Validador reverifica **só** os ids abertos mais uma varredura curta de regressão.

Repita até **zero BLOQUEANTES**. Limite de 3 rodadas; ao estourar, marque a sprint como **falha** com o relatório dos findings abertos e siga com as outras.

## Fase 3 — Integração determinística

Integre **na ordem do plano** (número da sprint), não na ordem em que terminaram.

Para cada sprint bem-sucedida, faça um merge de teste antes de aplicar:

```bash
git merge-tree $(git merge-base HEAD <branch>) HEAD <branch>
```

- Sem conflito → aplique o merge na árvore principal.
- Com conflito → **não resolva por conta própria** se o conflito for semântico; pare, mostre o conflito ao usuário e peça a decisão. Conflitos triviais de import/ordenação você pode resolver, declarando o que fez.

Depois de cada integração, rode os comandos de verificação do projeto. Se a integração quebrar algo que passava, trate como finding BLOQUEANTE da sprint recém-integrada e devolva ao Dev dela.

Sprints falhas **não são integradas**, e as irmãs seguem normalmente.

## Fase 4 — Resiliência

- **Falha operacional** (rede, timeout, instalação de dependência, processo morto): tente de novo até 2 vezes antes de marcar como falha. Falha de *correção* não é retentada automaticamente — vai para o loop de findings.
- **Pausa/retomada**: mantenha um `docs/features/<slug>/sprints/BUILD-STATE.md` atualizado a cada transição de estado (sprint pendente/rodando/validando/ok/falha, branch, worktree, rodada de findings). Se a sessão for interrompida, esse arquivo permite retomar sem refazer o que já passou. Ao iniciar, se ele existir, leia-o e retome de onde parou.
- Nunca faça commit na branch principal do usuário, nunca faça push, nunca abra PR sem pedido explícito.

## Fase 5 — Encerramento

1. Remova os worktrees das sprints integradas (`git worktree remove`). Mantenha os das sprints falhas para inspeção e diga onde estão.
2. Apresente o relatório final:
   - tabela sprint × status × rodadas de findings × arquivos tocados,
   - o que falhou e por quê, com os findings abertos,
   - resultado dos comandos de verificação no estado final integrado (com a saída real).
3. Deixe tudo **não commitado** na árvore de trabalho para a revisão de diffs do usuário. Diga isso explicitamente: nada entra no código dele sem ele ver.

