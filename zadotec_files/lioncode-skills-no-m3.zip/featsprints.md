---
name: featsprints
description: Gera um conjunto de sprints executáveis a partir de uma SPEC já pronta, pulando PRD e TECH e entrando direto na fase de sprints, com validador adversarial e gates de código. Use quando o usuário invocar /featsprints, apontar um arquivo de especificação e pedir "gera as sprints", "planeja a execução dessa spec", ou logo depois de /spec ou /bugreview quando a ficha/spec já está aprovada.
---

# /featsprints — Planejar sprints a partir de uma SPEC pronta

Atalho do pipeline de features: a especificação já existe (escrita fora, via `/spec`, ou vinda do handoff do `/bugreview`). Pula PRD e TECH e entra direto na fase de sprints, com os mesmos validadores e gates.

## Entrada

O caminho do arquivo da SPEC. Se o usuário não apontou:

1. Procure candidatos em `docs/specs/**/SPEC.md`, `docs/features/**/SPEC.md`, `docs/**/*spec*.md`.
2. Se houver exatamente um óbvio, use-o e avise. Se houver vários, pergunte qual — **uma** pergunta com a lista.

## Fase 0 — Leitura e ancoragem

1. Leia a SPEC inteira.
2. Mapeie o repositório: stack, convenções (`CLAUDE.md`/`AGENTS.md`), scripts reais de build/lint/test no manifesto.
3. **Verifique a SPEC contra o código antes de planejar**: abra cada arquivo que ela cita. Se ela referencia coisas que não existem ou descreve errado o comportamento atual, **pare e relate ao usuário** antes de gerar sprints — planejar em cima de uma spec desalinhada gera sprints inexecutáveis.
4. Se a SPEC não tem um plano de mudanças arquivo a arquivo, derive um você mesmo lendo o código, e mostre-o ao usuário para conferência.

## Fase 1 — Particionamento

Uma sprint é a menor unidade que:

- entrega valor verificável isoladamente,
- cabe num worktree isolado sem conflitar com as irmãs,
- tem critérios de aceitação e testes próprios.

Regras:

- Declare dependências explícitas e agrupe em **ondas**. Mesma onda = zero dependência mútua e zero sobreposição de arquivos.
- Dois itens que tocam o mesmo arquivo: ou viram uma sprint só, ou vão para ondas diferentes.
- Cobertura total: todo item de mudança da SPEC pertence a exatamente uma sprint.
- Sem dependências circulares.

## Fase 2 — Escrita

Escreva em `docs/features/<slug>/sprints/SPRINT-NN.md` (use o diretório da SPEC quando ela já mora em `docs/features/<slug>/`).

Formato de cada sprint:

```markdown
# SPRINT-NN — <título>

## Objetivo
Uma frase.

## Depende de
SPRINT-xx (ou: nenhuma)

## Onda
<número>

## Arquivos previstos
- caminho — criar/alterar/remover — o que muda

## Passos de implementação
1. ...

## Testes obrigatórios
- ...

## Critérios de aceitação
- [ ] CA-xx: ...

## Comandos de verificação
```bash
<comandos reais do projeto>
```
```

Gere também `sprints/PLANO.md` com a tabela de ondas × sprints e a **tabela de cobertura**: cada item da SPEC → a sprint que o cobre.

## Fase 3 — Validação adversarial

Dispare um subagente com contexto limpo, mandato de derrubar o plano:

"Leia a SPEC em `<caminho>` e as sprints em `<dir>`. Reporte findings com id estável `F-SP-<n>`, severidade (BLOQUEANTE | IMPORTANTE | NOTA) e evidência. BLOQUEANTE para: item da SPEC sem sprint que o cubra; dois arquivos iguais em sprints da mesma onda; dependência circular; comando de verificação que não existe no projeto (confira o manifesto); arquivo marcado 'alterar' que não existe no repositório; critério de aceitação não verificável. Não sugira melhorias de estilo."

**Gate de código**: rode o typecheck/lint do projeto e reporte o estado da base. Se já estiver quebrada antes de qualquer mudança, avise o usuário — isso invalida os comandos de verificação das sprints.

Corrija todos os BLOQUEANTES e revalide. Repita até zerar.

## Encerramento

Apresente: caminhos gerados, tabela de ondas, tabela de cobertura, findings não corrigidos com motivo.

Sugira o próximo passo: `/featbuild`.

