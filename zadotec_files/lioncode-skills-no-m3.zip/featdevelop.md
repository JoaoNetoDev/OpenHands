---
name: featdevelop
description: Pipeline completo de planejamento de feature de ponta a ponta — PRD, TECH, SPEC e sprints — com agentes especialistas escrevendo cada fase, validadores adversariais conferindo cada referência contra o código real, gates de código e aprovação do usuário entre fases. Use quando o usuário invocar /featdevelop, pedir para "planejar uma feature do zero", "montar o PRD e as sprints", "planejar de ponta a ponta", ou quando a feature ainda não tem nem documento nem plano.
---

# /featdevelop — Planejar uma feature de ponta a ponta

Pipeline: **PRD → TECH → SPEC → SPRINTS**. Cada fase é escrita, validada adversarialmente, passa por gate de código e **espera aprovação explícita do usuário** antes da próxima.

Se o usuário já tem uma SPEC pronta, não use esta skill — use `/featsprints`.

## Estrutura de saída

Tudo em `docs/features/<slug>/`, `<slug>` em kebab-case:

```
docs/features/<slug>/
  PRD.md
  TECH.md
  SPEC.md
  sprints/SPRINT-01.md, SPRINT-02.md, ...
  overview.html
```

## Regras que valem em todas as fases

- **Ancoragem obrigatória**: nenhuma referência a arquivo, função, tipo, rota, tabela, comando, dependência ou flag entra num documento sem ter sido lida no repositório. Cite `arquivo:linha`.
- **Validação adversarial**: o validador de cada fase trabalha com contexto limpo e o mandato de *derrubar* o documento, não de elogiá-lo.
- **Gate de fase**: só avança com zero findings BLOQUEANTES **e** aprovação do usuário.
- **Findings têm id estável** (`F-<fase>-<n>`) — o mesmo id acompanha a correção e a reverificação.
- Faça no máximo 2–3 perguntas por rodada ao usuário, e só onde a resposta muda o desenho.

## Fase 0 — Reconhecimento

Antes do PRD: mapeie stack, convenções (`CLAUDE.md`/`AGENTS.md`), estrutura de pastas, testes e como se roda build/lint/test. Identifique os módulos que a feature toca. Defina o `<slug>` e confirme com o usuário em uma linha.

## Fase 1 — PRD (produto)

Escritor: agente com foco em produto. Conteúdo de `PRD.md`:

1. Problema e evidência
2. Usuários e cenários de uso
3. Objetivos e não-objetivos
4. Requisitos funcionais numerados (`RF-01`, ...)
5. Requisitos não-funcionais (`RNF-01`, ...) — performance, segurança, acessibilidade, observabilidade
6. Métricas de sucesso
7. Escopo de release e faseamento
8. Riscos de produto e questões em aberto

**Validador adversarial do PRD**: subagente com contexto limpo. Mandato: "Encontre requisitos não verificáveis, objetivos sem métrica, escopo ambíguo, requisitos que contradizem o comportamento atual do produto (confirme lendo o código), e não-objetivos que na prática são necessários para o objetivo. Reporte findings com id, severidade e citação."

**Gate**: zero BLOQUEANTES → apresente o PRD ao usuário e **pare até ele aprovar**.

## Fase 2 — TECH (arquitetura)

Escritor: agente com foco em arquitetura, lendo PRD + código. Conteúdo de `TECH.md`:

1. Estado atual da arquitetura nos pontos tocados, com `arquivo:linha`
2. Arquitetura proposta — componentes, responsabilidades, limites
3. Modelo de dados e migrações
4. Contratos: APIs, eventos, tipos públicos, assinaturas
5. Alternativas consideradas e por que foram rejeitadas
6. Segurança, permissões e privacidade
7. Performance e escala
8. Observabilidade — logs, métricas, erros
9. Estratégia de testes
10. Rollout, feature flag e rollback
11. Rastreabilidade: cada `RF-xx`/`RNF-xx` do PRD → onde é atendido aqui

**Validador adversarial do TECH**: "Confira **cada** referência ao código abrindo o arquivo citado. Marque como BLOQUEANTE toda referência inexistente ou descrita incorretamente. Além disso: aponte onde o desenho quebra invariantes existentes, ignora um caminho de erro real, ou propõe algo incompatível com as dependências instaladas (confira o manifesto). Aponte requisitos do PRD sem cobertura."

**Gate de código**: rode o typecheck/lint do projeto para confirmar que a base está limpa antes de planejar em cima dela; relate se não estiver.

**Gate**: zero BLOQUEANTES → apresente e **pare até aprovação**.

## Fase 3 — SPEC (design detalhado)

Escritor: agente de design detalhado, lendo PRD + TECH + código. Conteúdo de `SPEC.md`:

1. Resumo e escopo
2. Desenho detalhado por componente, com as assinaturas exatas a criar/alterar
3. Fluxo principal passo a passo e fluxos de erro
4. Casos de borda: concorrência, dados legados, limites, entradas inválidas
5. Mudanças arquivo a arquivo — lista de arquivos a criar, alterar, remover, com o que muda em cada um
6. Critérios de aceitação verificáveis (`CA-01`, ...), cada um mapeado a um `RF`/`RNF`
7. Plano de testes: unidade, integração, e2e — o que cada um cobre

**Validador adversarial da SPEC**: "Verifique cada caminho de arquivo e cada assinatura contra o repositório. BLOQUEANTE para caminho inexistente onde a spec diz 'alterar', assinatura incompatível com o chamador real, ou critério de aceitação não testável. Verifique que todo `CA` cobre pelo menos um `RF`/`RNF` e que todo `RF`/`RNF` tem `CA`."

**Gate**: zero BLOQUEANTES → apresente e **pare até aprovação**.

## Fase 4 — SPRINTS

Quebre a SPEC em sprints executáveis. Uma sprint é a menor unidade que:

- entrega valor verificável isoladamente,
- cabe num worktree isolado sem conflitar com as irmãs,
- tem critérios de aceitação próprios e testes próprios.

Cada `sprints/SPRINT-NN.md` contém:

```markdown
# SPRINT-NN — <título>

## Objetivo
Uma frase.

## Depende de
SPRINT-xx (ou: nenhuma)

## Onda
<número> — sprints da mesma onda rodam em paralelo

## Arquivos previstos
- caminho — criar/alterar/remover — o que muda

## Passos de implementação
1. ...

## Testes obrigatórios
- ...

## Critérios de aceitação
- [ ] CA-xx: ...

## Comandos de verificação
```bash
<comandos reais de test/lint/build do projeto>
```
```

Regras de particionamento:
- Declare dependências explicitamente e agrupe em **ondas**: mesma onda = sem dependência entre si e sem sobreposição de arquivos.
- Se duas sprints mexem no mesmo arquivo, ou vira uma sprint só, ou vão para ondas diferentes.
- Cobertura total: todo item do plano de mudanças da SPEC pertence a exatamente uma sprint. Verifique isso explicitamente e mostre a tabela de cobertura.

**Validador adversarial das SPRINTS**: "Verifique: cobertura total da SPEC (item sem sprint = BLOQUEANTE), sobreposição de arquivos dentro de uma mesma onda (BLOQUEANTE), dependências circulares (BLOQUEANTE), sprints grandes demais para uma execução isolada, comandos de verificação que não existem no projeto (confira os scripts do manifesto)."

**Gate**: zero BLOQUEANTES.

## Fase 5 — Visão executiva

Gere `overview.html`: uma página autocontida (CSS inline, sem dependências externas) para quem não é técnico. Contém: o problema, o que será entregue, as ondas e sprints numa linha do tempo, riscos e o que fica de fora. Linguagem sem jargão. Deve funcionar em tema claro e escuro.

## Encerramento

Apresente ao usuário:
- os caminhos gerados,
- a tabela de sprints por onda,
- os findings aceitos como IMPORTANTE/NOTA sem correção, com o motivo.

Sugira o próximo passo: `/featbuild`.

