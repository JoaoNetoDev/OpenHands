---
name: bugreview
description: Diagnostica um bug descrito em uma frase — dois tracers investigam em paralelo, um pelo código e outro pelo comportamento, e o diagnóstico consolidado vira uma ficha revisável (BUG, TRACE, DIAGNÓSTICO) que o usuário aprova antes de qualquer correção. Use quando o usuário invocar /bugreview, relatar um bug, uma falha de teste ou um comportamento inesperado e pedir a causa raiz, ou disser "investiga esse bug", "por que isso está acontecendo", "diagnostica esse erro".
---

# /bugreview — Diagnosticar um bug

Bug entra numa ponta, correção revisada sai na outra. Esta skill vai até o **diagnóstico aprovado** — a correção segue pelo trilho das features.

**Regra dura**: nada de correção antes da ficha aprovada. Se você identificar a causa raiz na primeira leitura, ainda assim escreva a ficha e espere a aprovação.

## Entrada

Uma frase descrevendo o bug. Se vier vago demais para investigar, pergunte **o mínimo**: o que era esperado, o que aconteceu, e como reproduzir. Se o usuário não sabe reproduzir, siga assim mesmo — o tracer de comportamento tenta descobrir.

## Fase 0 — Contexto

Monte o essencial antes de disparar os tracers: stack, estrutura, mensagens de erro, teste que falha, commits recentes na área suspeita (`git log`), e o `CLAUDE.md`/`AGENTS.md`. Nada de conclusões ainda.

## Fase 1 — Dois tracers em paralelo

Dispare **os dois na mesma mensagem**, com contexto limpo, sem que um veja o outro. A independência é o valor: convergência entre eles é evidência, divergência é sinal de que a causa raiz ainda não apareceu.

**Tracer A — pelo código (estático).** Mandato:

> Bug relatado: "<descrição>". Investigue **lendo o código**: parta do sintoma, siga o caminho de execução para trás até a origem, leia as funções envolvidas de verdade, cheque invariantes, tratamento de erro, concorrência, tipos e mudanças recentes (`git log -p` na área). Não rode a aplicação. Retorne: caminho de execução com `arquivo:linha`, a hipótese de causa raiz, a evidência exata em código que a sustenta, e o nível de confiança. Se não achar, diga o que descartou e por quê. Não proponha correção.

**Tracer B — pelo comportamento (dinâmico).** Mandato:

> Bug relatado: "<descrição>". Investigue **observando o sistema**: reproduza, rode os testes relacionados, use logs e instrumentação temporária, bissecione a entrada, teste os limites. Retorne: passos exatos de reprodução, saídas reais dos comandos, condições em que o bug aparece e em que não aparece, a hipótese de causa raiz e o nível de confiança. Reverta qualquer instrumentação temporária antes de terminar. Não proponha correção.

## Fase 2 — Consolidação

Compare os dois relatos:

- **Convergem** → causa raiz com confiança alta. Registre as duas evidências.
- **Divergem** → não escolha um dos dois por preferência. Dispare uma terceira investigação focada exatamente no ponto de desacordo, e resolva com evidência.
- **Nenhum conclui** → diga isso claramente na ficha, liste o que foi descartado e proponha o próximo passo de investigação. Não invente causa raiz.

## Fase 3 — A ficha

Escreva `docs/bugs/<slug>/FICHA.md`:

```markdown
# BUG — <título curto>

## BUG
- Sintoma: o que o usuário vê
- Esperado: o que deveria acontecer
- Reprodução: passos exatos
- Escopo: quem é afetado, desde quando, gravidade

## TRACE
### Tracer A — código
Caminho de execução com arquivo:linha e a evidência.
### Tracer B — comportamento
Reprodução, saídas reais, condições de contorno.
### Convergência
Onde os dois concordam e onde divergem, e como a divergência foi resolvida.

## DIAGNÓSTICO
- Causa raiz: uma frase, apontando `arquivo:linha`
- Por que causa o sintoma: a cadeia causal
- Por que passou despercebido: o teste ou guarda que faltou
- Confiança: alta | média | baixa, com o motivo
- Impacto colateral: o que mais depende desse ponto
- Correção proposta (direção, não implementação)
- Regressão a cobrir: o teste que deve existir e hoje não existe
- Alternativas descartadas
```

## Fase 4 — Aprovação

Apresente a ficha ao usuário e **pare**. Ele aprova, corrige ou pede mais investigação. Sem aprovação, nada de código.

## Fase 5 — Handoff

Aprovada a ficha, a correção segue pelo caminho das features:

1. Converta a ficha em uma especificação de correção em `docs/bugs/<slug>/SPEC.md`: escopo do fix, mudanças arquivo a arquivo, testes de regressão obrigatórios e critérios de aceitação verificáveis.
2. Invoque `/featsprints` apontando para essa SPEC para gerar as sprints do fix.
3. `/featbuild` executa.

Se essas skills não estiverem disponíveis na sessão, diga isso e siga com o fluxo padrão de implementação, mantendo o teste de regressão como item obrigatório.

